$(document).ready(function() {

  $('.agregar').click(function() {
    var nombreFruta = $('#nombre_fruta').val();
    console.log(nombreFruta);
    var text = "<li>" + nombreFruta + ' <button type="button" class="borrar">Borrar</button></li>';
    $('#listado_frutas > ul').append(text);
    $('.borrar').click(function() {
      $(this).closest('li').remove();
    });
  });

  $('.borrar').click(function() {
    $(this).closest('li').remove();
  });

});
